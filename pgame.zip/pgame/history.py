import pickle

class History:

    path = "history/history.data"

    # 保存当前分数
    @staticmethod
    def put(score: int)->None:
        history = History.get()
        for idx in range(0, len(history)):
            if history[idx] < score:
                history.insert(idx,score)
                break
        with open(History.path, 'wb') as file:
            pickle.dump(history[:5], file, protocol = 1)

    # 获取历史top5分数
    @staticmethod
    def get()->list:
        with open(History.path, 'rb') as file:
            history = pickle.load(file)
            history.sort(reverse = True)
            return history