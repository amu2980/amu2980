import pygame
import sys
from history import *
from button import *

# 载入背景图片
bg = pygame.image.load("./img/rank_bg.jpg")
# 退出按钮
exitGameimg = pygame.image.load("img/exitGame.png")
exitGameimg = pygame.transform.scale(exitGameimg,(100,100))
    # 退出按钮被选中
exitGameLightimg = pygame.image.load("img/exitGameLight.png")
exitGameLightimg = pygame.transform.scale(exitGameLightimg,(100,100))

class Rank:

    def __init__(self, screen, mouse_down_sound):
        self.screen = screen
        self.mouse_down = mouse_down_sound
        self.bgimg = pygame.transform.scale(bg, (screen.get_width(), screen.get_height()))

    def start(self):
        # 获取排行
        scores = History.get()
        # 初始化排行显示组件
        color = (255, 255, 255)
        font = pygame.font.Font(None, 80)
        font2 = pygame.font.Font(None, 60)
        title_pos = (550, 50)
        title_img = font.render("Ranking-List", True, color)

        names = ["rank1","rank2","rank3","rank4","rank5"]
        name_imgs = []
        name_poses = [(450,150),(450,250),(450,350),(450,450),(450,550)]
        for name in names:
            name_imgs.append(font2.render(name, True, color))

        score_imgs = []
        score_poses = [(950,150),(950,250),(950,350),(950,450),(950,550)]
        for score in scores:
            score_imgs.append(font2.render(str(score), True, color))

        exit_button = Button(self.screen, exitGameimg, None, 640, centered_x=True)

        while True:

            self.screen.blit(self.bgimg, (0,0))
            self.screen.blit(title_img, title_pos)

            if exit_button.check_click(pygame.mouse.get_pos()):
                exit_button.img = exitGameLightimg
            else:
                exit_button.img = exitGameimg

            for idx in range(0, len(score_imgs)):
                self.screen.blit(name_imgs[idx], name_poses[idx])
                self.screen.blit(score_imgs[idx], score_poses[idx])

            exit_button.move()

            pygame.display.update()

            for event in pygame.event.get():

                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    # 判断单击退出按钮
                    if exit_button.check_click(pygame.mouse.get_pos()):
                        # print("exit") # debug
                        self.mouse_down.play()
                        return None

