import random
import sys
import pygame
import time
import base

# 刺鱼
enemy1_1_img = pygame.image.load("./img/enemy0_1.png")
enemy1_right_img = pygame.image.load("./img/enemy0right_1.png")
# 小鱼
enemy2_img = pygame.image.load("./img/enemy2.png")
enemy2_right_img = pygame.image.load("./img/enemy2right.png")
# 中鱼
enemy3_img = pygame.image.load("img/enemy3.png")
enemy3_right_img = pygame.image.load("./img/enemy3right.png")
# 大鱼
enemy4_1_img = pygame.image.load("./img/enemy4_1.png")
enemy4_2_img = pygame.image.load("./img/enemy4_2.png")
enemy4_3_img = pygame.image.load("./img/enemy4_3.png")
enemy4_4_img = pygame.image.load("./img/enemy4_4.png")
enemy4_right_1_img = pygame.image.load("./img/enemy4right_1.png")
enemy4_right_2_img = pygame.image.load("./img/enemy4right_2.png")
enemy4_right_3_img = pygame.image.load("./img/enemy4right_3.png")
enemy4_right_4_img = pygame.image.load("./img/enemy4right_4.png")
# 构造图片列表，便于管理
img_list = [(enemy1_1_img,enemy1_1_img),
            (enemy2_img,enemy2_img),
            (enemy3_img,enemy3_img),
            (enemy4_1_img,enemy4_2_img,enemy4_3_img,enemy4_4_img)]
right_img_list = [(enemy1_right_img,enemy1_right_img),
            (enemy2_right_img,enemy2_right_img),
            (enemy3_right_img,enemy3_right_img),
            (enemy4_right_1_img,enemy4_right_2_img,enemy4_right_3_img,enemy4_right_4_img)]

# 各单位的横纵速度
speed_list = [(1,1),(2,3),(3,1),(3,2)]
# 各单位的大小
size_list = [(50,50),(40,40),(100,78),(280,140)]
# 各单位的延时器时间
interval_list = [5,8,10,10]
# 各单位碰撞判定收缩距离
padding_list = [(15,15),(15,15),(30,20),(50,30)]
# 被吃掉后的刷新冷却时间
pause_time_list = [0, 2000, 4000, 0]
# 被吃掉后价值的分数
value_list = [0, 10, 50, 100]

class Enemy(base.Base):

    def __init__(self, screen, level):
        super().__init__(screen)
        self.level = level
        self.score = value_list[self.level]
        self.delay = 1000
        self.count_delay = self.delay
        self.interval = interval_list[self.level]
        self.vx,self.vy = speed_list[self.level]
        self.width,self.height = size_list[self.level]
        self.enemy_imgs = []
        self.enemy_right_imgs = []
        for idx in range(0,len(img_list[self.level])):
            self.enemy_imgs.append(
                pygame.transform.scale(img_list[self.level][idx],(self.width,self.height)))
            self.enemy_right_imgs.append(
                pygame.transform.scale(right_img_list[self.level][idx],(self.width,self.height)))
        self.rect = self.enemy_imgs[0].get_rect()
        # 随机刷新位置
        if random.randint(0, 1) == 0:
            self.rect.x = random.randint(-self.width, 300)
        else :
            self.rect.x = random.randint(900,1200 + self.width)
        self.rect.y = random.randint(-self.height, self.screen.get_height())
        # 随机移动方向
        if random.randint(0, 1) == 0:
            self.vx = -self.vx
            self.is_right = False
        else :
            self.is_right = True
        # self.screen.blit(self.enemy_img, self.rect)
        self.img_idx = 0
        
    def move(self):
        self.count_delay -= 1
        if not self.count_delay:
            self.count_delay = self.delay

        if self.count_delay <= self.delay:

            if self.count_delay % self.interval == 0:
                if self.rect.x < -self.width or self.rect.x > self.screen.get_width():
                    self.vx = -self.vx
                    self.is_right = not self.is_right
                if self.rect.y < -self.height or self.rect.y > self.screen.get_height():
                    self.vy = -self.vy
                self.rect.x += self.vx
                self.rect.y += self.vy

                self.img_idx = (self.img_idx + 1) % len(self.enemy_imgs)
                self.turn_random(0.005)

            if self.is_right:
                self.screen.blit(self.enemy_right_imgs[self.img_idx], self.rect)
            else :
                self.screen.blit(self.enemy_imgs[self.img_idx], self.rect)
        
    def get_xyl(self):
        return self.rect.x+padding_list[self.level][0], \
               self.rect.y+padding_list[self.level][1], \
               self.width-padding_list[self.level][0], \
               self.height-padding_list[self.level][1]

    def initial(self):
        self.count_delay = pause_time_list[self.level]

        if random.randint(0, 1) == 0:
            self.rect.x = random.randint(-self.width, 300)
        else:
            self.rect.x = random.randint(900, 1200 + self.width)
        self.rect.y = random.randint(-self.height, self.screen.get_height())

        if self.vx < 0 :
            self.is_right = False
        else:
            self.is_right = True

    def is_in_initial(self) -> bool:
        if self.count_delay > self.delay:
            return True
        else :
            return False

    def turn_random(self, probability):

        num = int(probability*1000)
        if random.randint(0, 1000) <= num:
            self.vx = -self.vx
        if self.vx < 0 :
            self.is_right = False
        else:
            self.is_right = True

    def speed_up(self):

        if self.interval > 1:
            self.interval -= 1

        if self.vx > 0 :
            self.vx += 1
        else :
            self.vx -= 1
        if self.vy > 0 :
            self.vy += 1
        else :
            self.vy -= 1

# def print_text(font, text, pos, color):
#     imgText = font.render(text, True, color)

