import pygame
import base

# 各等级碰撞判定收缩距离
padding_list = [(20, 10),(30, 15),(40, 20)]
# 角色图片显示
me_1_img = pygame.image.load("img/me_1.png")
me_2_img = pygame.image.load("img/me_2.png")
me_3_img = pygame.image.load("img/me_3.png")
meright_1_img = pygame.image.load("img/meright_1.png")
meright_2_img = pygame.image.load("img/meright_2.png")
meright_3_img = pygame.image.load("img/meright_3.png")
me_imgs = [me_1_img,me_2_img,me_3_img]
right_me_imgs = [meright_1_img, meright_2_img, meright_3_img]
# 眩晕显示图片
dizzy1img = pygame.image.load("img/dizzy1.png")
dizzy2img = pygame.image.load("img/dizzy2.png")
dizzy3img = pygame.image.load("img/dizzy3.png")
dizzy4img = pygame.image.load("img/dizzy4.png")
dizzy5img = pygame.image.load("img/dizzy5.png")
dizzy6img = pygame.image.load("img/dizzy6.png")
dizzy_list = [dizzy1img,dizzy2img,dizzy3img,dizzy4img,dizzy5img,dizzy6img]
# 分数显示框图片
scoreimg = pygame.image.load("img/scoreBar.png")
# 各等级的大小
size_list = [(79,70),(123,110),(141,125)]

class Me(base.Base):

    def __init__(self, screen):
        super().__init__(screen)
        self.level = 1
        self.meimgs = []
        self.merightimgs = []
        for idx in range(0, len(me_imgs)):
            self.meimgs.append(
                pygame.transform.scale(me_imgs[idx], size_list[self.level-1]))
            self.merightimgs.append(
                pygame.transform.scale(right_me_imgs[idx], size_list[self.level-1]))
        # self.width = self.meimgs[0].get_width()
        # self.height = self.meimgs[0].get_height()
        self.rect = self.meimgs[0].get_rect()
        self.isDizzy = False
        self.dizzy_time = 0
        self.isright = False
        self.score = 0
        self.dizzy_rect = dizzy1img.get_rect()
        self.dizzy_idx = 0
        self.is_max = False
        self.scoreimg = scoreimg
        self.score_rect = self.scoreimg.get_rect()
        self.score_rect.x = 1340
        self.score_rect.y = 18
        self.img_idx = 0

    def move(self):

        if self.isDizzy:
            self.dizzy_time -= 1
            if self.dizzy_time == 0:
                self.isDizzy = False
            pygame.mouse.set_pos(self.rect.x, self.rect.y)
            self.dizzy_rect.x = self.rect.x
            self.dizzy_rect.y = self.rect.y
            self.screen.blit(dizzy_list[self.dizzy_idx],self.dizzy_rect)
            if self.dizzy_time % 8 == 0:
                self.dizzy_idx = (self.dizzy_idx + 1) % len(dizzy_list)
        else :
            MOS_x, MOS_y = pygame.mouse.get_pos()
            if MOS_x > self.rect.x:
                self.isright = True
                self.img_idx = (self.img_idx + 1) % len(self.meimgs)
            elif MOS_x < self.rect.x:
                self.isright = False
                self.img_idx = (self.img_idx + 1) % len(self.meimgs)

            if MOS_x - self.rect.width / 2 < -self.rect.width:
                MOS_x = self.rect.width / 2
            if MOS_x + self.rect.width / 2 > self.screen.get_width() - self.rect.width:
                MOS_x = self.screen.get_width() - self.rect.width
            if MOS_y - self.rect.height / 2 < -self.rect.height:
                MOS_y = self.rect.height / 2
            if MOS_y + self.rect.height / 2 > self.screen.get_height() - self.rect.height:
                MOS_y = self.screen.get_height() - self.rect.height

            self.rect.x = MOS_x
            self.rect.y = MOS_y

        if self.isright:
            self.screen.blit(self.merightimgs[self.img_idx], self.rect)
        else :
            self.screen.blit(self.meimgs[self.img_idx], self.rect)

    def get_xyl(self):
        return self.rect.x+padding_list[self.level-1][0], \
               self.rect.y+padding_list[self.level-1][1], \
               self.rect.width-padding_list[self.level-1][0], \
               self.rect.height-padding_list[self.level-1][1]

    def dizzy(self):
        self.isDizzy = True
        self.dizzy_time = 300

    def add_score(self, score):
        self.score += score

    def grow(self):
        self.level += 1
        # print("level = ", self.level) # debug
        self.meimgs.clear()
        self.merightimgs.clear()
        for idx in range(0, len(me_imgs)):
            self.meimgs.append(
                pygame.transform.scale(me_imgs[idx], size_list[self.level - 1]))
            self.merightimgs.append(
                pygame.transform.scale(right_me_imgs[idx], size_list[self.level - 1]))
        x, y = self.rect.x, self.rect.y
        self.rect = self.meimgs[0].get_rect()
        self.rect.x, self.rect.y = x, y
        # self.width = self.meimg.get_width()
        # self.height = self.meimg.get_height()

    def show_score(self, font, color, score_pos):
        self.screen.blit(self.scoreimg, self.score_rect)
        score_img = font.render(str(self.score), True, color)
        self.screen.blit(score_img, score_pos)

    def pause(self):
        pygame.mouse.set_pos(self.rect.x, self.rect.y)