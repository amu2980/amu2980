import pygame

class Base:

    def __init__(self, screen):
        if not isinstance(screen, pygame.Surface):
            raise Exception("class type error!")
        self.screen = screen

    def move(self):
        pass

    def get_xyl(self):
        pass