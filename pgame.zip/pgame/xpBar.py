import pygame
from base import *

# 载入经验条图片
xp_img = pygame.image.load("img/xp_bar_empty.png")
xp_full_img = pygame.image.load("img/xp_bar_full.png")

class XpBar(Base):

    def __init__(self, screen):
        super().__init__(screen)
        self.xp_img = pygame.transform.scale(xp_img, (211, 41))
        self.xp_full_img = pygame.transform.scale(xp_full_img, (0, 41))
        self.rect = self.xp_img.get_rect()
        self.rect.x = 10
        self.rect.y = 10
        # 用于优化性能
        self.last_percent = 0

    def move(self):
        pass

    def update(self, percent):
        # self.full_rect.width = percent * self.rect.width
        if self.last_percent != percent:
            self.last_percent = percent
            self.xp_full_img = pygame.transform.scale(xp_full_img,
                             (int(percent*self.rect.width), self.rect.height))
        self.screen.blit(self.xp_img, self.rect)
        self.screen.blit(self.xp_full_img, self.rect)