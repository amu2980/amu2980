import pygame
import random
import base

# 泡泡图片
bubbleimg = pygame.image.load("img/buble.png")

class Bubble(base.Base):

    def __init__(self, screen, size, position, speed, interval):
        super().__init__(screen)
        self.bubbleimg = pygame.transform.scale(bubbleimg, (size, size))
        self.rect = self.bubbleimg.get_rect()
        self.position = position
        if position == "left":
            self.rect.x = random.randint(50, 450)
        elif position == "right":
            self.rect.x = random.randint(1050,1450)
        self.rect.y = self.screen.get_height() + 50
        self.delay = 1000
        self.speed = speed
        self.interval = interval

    def move(self):
        self.delay -= 1
        # 延时器归零时复位
        if not self.delay:
            self.delay = 1000
        # 延时器符合条件时移动
        if self.delay % self.interval == 0:
            self.rect.y -= self.speed
        # 移动出屏幕时重新构造位置
        if self.rect.y < -self.rect.height:
            if self.position == "left":
                self.rect.x = random.randint(50, 450)
            elif self.position == "right":
                self.rect.x = random.randint(1050, 1450)
            self.rect.y = self.screen.get_height() + 50
        self.screen.blit(self.bubbleimg, self.rect)

    # 点击泡泡使泡泡加速
    def speed_up(self):
        self.speed += 1
        if self.interval > 0:
            self.interval -= 1

    # 判断鼠标单击是否在泡泡上
    def check_click(self, position):

        x_match = position[0] > self.rect.x and position[0] < self.rect.x + self.rect.width
        y_match = position[1] > self.rect.y and position[1] < self.rect.y + self.rect.height

        if x_match and y_match:
            return True
        else:
            return False