import pygame
import sys
import play
import rank
import bubble
import button

display_width = 1500
display_height = 800

pygame.init()

# 图片加载
# 背景图片
bg = pygame.image.load('img/home.jpg')
bg = pygame.transform.scale(bg,(display_width,display_height))
# 音效
    # 鼠标单击选项音效
mouse_down = pygame.mixer.Sound("./sound/mouseDown.ogg")
    # 泡泡点击音效
bubble_sound = pygame.mixer.Sound("./sound/bubbleClick.ogg")
# 标题板
titleimg = pygame.image.load('img/titleBoard.png')
titleimg = pygame.transform.scale(titleimg, (500,170))
    # 设置游戏标题版位置
title_rect = titleimg.get_rect()
title_rect.x = display_width // 2 - title_rect.width // 2
title_rect.y = 100
# 开始按钮
startGameimg = pygame.image.load("img/startGame.png")
startGameimg = pygame.transform.scale(startGameimg,(100,100))
    # 开始按钮被选中
startGameLightimg = pygame.image.load("img/startGameLight.png")
startGameLightimg = pygame.transform.scale(startGameLightimg,(100,100))
# 退出按钮
exitGameimg = pygame.image.load("img/exitGame.png")
exitGameimg = pygame.transform.scale(exitGameimg,(100,100))
    # 退出按钮被选中
exitGameLightimg = pygame.image.load("img/exitGameLight.png")
exitGameLightimg = pygame.transform.scale(exitGameLightimg,(100,100))
# 排行按钮
rankimg = pygame.image.load("img/rank.png")
rankimg = pygame.transform.scale(rankimg,(100,100))
    # 排行按钮被选中
rankLightimg = pygame.image.load("img/rankLight.png")
rankLightimg = pygame.transform.scale(rankLightimg,(100,100))

def starting_screen():
    # 背景音乐
    pygame.mixer.music.load("./sound/bubbles2.ogg")
    pygame.mixer.music.play()
    while True:
        # 按钮特效
        if play_button.check_click(pygame.mouse.get_pos()):
            play_button.img = startGameLightimg
        else:
            play_button.img = startGameimg

        if exit_button.check_click(pygame.mouse.get_pos()):
            exit_button.img = exitGameLightimg
        else:
            exit_button.img = exitGameimg

        if rank_button.check_click(pygame.mouse.get_pos()):
            rank_button.img = rankLightimg
        else:
            rank_button.img = rankimg

        # 绘制元素，刷新屏幕
        screen.blit(bg,(0,0))
        screen.blit(titleimg, title_rect)
        play_button.move()
        exit_button.move()
        rank_button.move()
        # 移动泡泡
        for bubble in bubbles:
            bubble.move()

        pygame.display.update()

        # 事件响应
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                # print(pygame.mouse.get_pos()) # debug显示鼠标单击下的位置
                # 判断单击游戏按钮
                if play_button.check_click(pygame.mouse.get_pos()):
                    # print("play") # debug
                    mouse_down.play()
                    play.start()
                # 判断单击退出按钮
                if exit_button.check_click(pygame.mouse.get_pos()):
                    # print("exit") # debug
                    mouse_down.play()
                    pygame.quit()
                    sys.exit()
                # 判断单击排行按钮
                if rank_button.check_click(pygame.mouse.get_pos()):
                    mouse_down.play()
                    rank.start()
                # 判断单击泡泡
                for bubble in bubbles:
                    if bubble.check_click(pygame.mouse.get_pos()):
                        bubble_sound.play()
                        bubble.speed_up()

screen = pygame.display.set_mode((display_width, display_height))

# 页面按钮对象
play_button = button.Button(screen, startGameimg, None, 350, centered_x=True)
exit_button = button.Button(screen, exitGameimg, None, 470, centered_x=True)
rank_button = button.Button(screen, rankimg, None, 590, centered_x=True)
# 游戏页面对象
play = play.Play(screen)
# 排行页面对象
rank = rank.Rank(screen, mouse_down)
# 泡泡对象
bubble1 = bubble.Bubble(screen, size = 40, position = "left", speed = 3, interval = 12)
bubble2 = bubble.Bubble(screen, size = 60, position = "right", speed = 2, interval = 10)
bubble3 = bubble.Bubble(screen, size = 20, position = "left", speed = 4, interval = 10)
bubble4 = bubble.Bubble(screen, size = 20, position = "right", speed = 3, interval = 7)
# 使用一个列表存放泡泡，便于管理
bubbles = [bubble1, bubble2, bubble3, bubble4]

starting_screen()