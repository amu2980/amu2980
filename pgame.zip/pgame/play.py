import pygame
import sys
from enemy import *
from me import *
from xpBar import *
from history import *

bg = pygame.image.load("img/cave_bg.jpg")

class Play:

    def __init__(self, screen):
        self.screen = screen
        self.bgimg = pygame.transform.scale(bg, (screen.get_width(), screen.get_height()))

    def start(self):
        b1 = Enemy(self.screen, level = 0)
        b2 = Enemy(self.screen, level = 0)
        b3 = Enemy(self.screen, level = 1)
        b4 = Enemy(self.screen, level = 2)
        b5 = Enemy(self.screen, level = 3)
        b6 = Enemy(self.screen, level = 1)
        b7 = Enemy(self.screen, level = 1)
        b8 = Enemy(self.screen, level = 2)
        b9 = Enemy(self.screen, level = 0)
        b10 = Enemy(self.screen, level = 3)
        enemies = [b1,b2,b3,b4,b5,b6,b7,b8,b9,b10]
        # 初始化玩家角色
        me = Me(self.screen)
        # 初始化经验栏
        xp = XpBar(self.screen)
        # 升级所需分数
        # xp_list = [0, 50, 500, 800, 1200, 2000]
        xp_list = [0, 50, 200, 200, 200, 200]
        xp_level = 1
        # 初始化音效
        bite1_sound = pygame.mixer.Sound("./sound/bite1.ogg")
        bite2_sound = pygame.mixer.Sound("./sound/bite3.ogg")
        grow_sound = pygame.mixer.Sound("./sound/grow.ogg")
        stun_sound = pygame.mixer.Sound("./sound/stun.ogg")
        # 初始化分数显示组件
        color = (0, 0, 0)
        color2 = (255,255,255)
        font = pygame.font.Font(None, 50)
        score_pos = (1390, 30)
        xp_level_pos = (225, 20)

        flag = True

        while True:

            while flag:
                self.screen.blit(self.bgimg, (0, 0))
                pygame.mouse.set_visible(False)

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        sys.exit()
                    keys = pygame.key.get_pressed()
                    if keys[pygame.K_ESCAPE]:
                        sys.exit()
                    if keys[pygame.K_q]:
                        flag = False

                me.move()

                for enemy in enemies:
                    enemy.move()
                    # 检测碰撞
                    if not enemy.is_in_initial() and self.isCollision(me, enemy) :
                        # 判断与碰撞敌人的低级高低
                        if enemy.level == 0:
                            if not me.isDizzy:
                                stun_sound.play()
                                me.dizzy()
                        elif enemy.level == 3:
                            bite2_sound.play()
                            # flag = False  # debug
                            History.put(me.score)
                            pygame.mouse.set_visible(True)
                            # 己方角色被吃掉
                            return None
                        elif me.level >= enemy.level:
                            bite1_sound.play()
                            me.add_score(enemy.score)
                            # print(me.score) # debug
                            if (me.score-xp_list[xp_level-1]) >= xp_list[xp_level]:
                                if xp_level < len(xp_list) - 1:
                                    xp_level += 1
                                    for each in enemies:
                                        each.speed_up()
                                    # print(f"xp_level = {xp_level}") # debug
                                # print("grow up") # debug
                                if not me.is_max:
                                    grow_sound.play()
                                    me.grow()
                                    if me.level >= 3:
                                        me.is_max = True
                            enemy.initial()
                        else :
                            bite2_sound.play()
                            # flag = False # debug
                            History.put(me.score)
                            pygame.mouse.set_visible(True)
                            # 己方角色被吃掉
                            return None

                me.show_score(font, color, score_pos)
                xp.update(((me.score-xp_list[xp_level-1]) / xp_list[xp_level])
                          if xp_level < len(xp_list)-1
                          else 1)
                xp_level_img = font.render(f"x{xp_level}", True, color2)
                self.screen.blit(xp_level_img, xp_level_pos)

                pygame.display.update()

            while not flag:
                me.pause()
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        # print(me.score) # debug
                        pygame.quit()
                        sys.exit()
                    keys = pygame.key.get_pressed()
                    if keys[pygame.K_ESCAPE]:
                        # print(me.score) # debug
                        sys.exit()
                    if keys[pygame.K_g]:
                        flag = True

    def isCollision(self, recta, rectb):
        a_x, a_y, a_width, a_height = recta.get_xyl()
        b_x, b_y, b_width, b_height = rectb.get_xyl()

        a_v1 = a_x, a_y
        a_v2 = a_x+a_width, a_y
        a_v3 = a_x, a_y+a_height
        a_v4 = a_x+a_width, a_y+a_height

        b_v1 = b_x, b_y
        b_v2 = b_x+b_width, b_y
        b_v3 = b_x, b_y+b_height
        b_v4 = b_x + b_width, b_y + b_height

        if b_v1[0] < a_v1[0] < b_v4[0] \
                and b_v1[1] < a_v1[1] < b_v4[1]:
            # print("v1a") # debug
            return True
        if b_v1[0] < a_v2[0] < b_v4[0] \
                and b_v1[1] < a_v2[1] < b_v4[1]:
            # print("v2a") # debug
            return True
        if b_v1[0] < a_v3[0] < b_v4[0] \
                and b_v1[1] < a_v3[1] < b_v4[1]:
            # print("v3a") # debug
            return True
        if b_v1[0] < a_v4[0] < b_v4[0] \
                and b_v1[1] < a_v4[1] < b_v4[1]:
            # print("v4a") # debug
            return True

        if a_v1[0] < b_v1[0] < a_v4[0] \
                and a_v1[1] < b_v1[1] < a_v4[1]:
            # print("v1b") # debug
            return True
        if a_v1[0] < b_v2[0] < a_v4[0] \
                and a_v1[1] < b_v2[1] < a_v4[1]:
            # print("v2b") # debug
            return True
        if a_v1[0] < b_v3[0] < a_v4[0] \
                and a_v1[1] < b_v3[1] < a_v4[1]:
            # print("v3b") # debug
            return True
        if a_v1[0] < b_v4[0] < a_v4[0] \
                and a_v1[1] < b_v4[1] < a_v4[1]:
            # print("v4b") # debug
            return True

        return False


