import pygame

class Button(object):

    def __init__(self, screen, img, x=None, y=None, **kwargs):

        self.screen = screen

        self.img = img
        self.rect = img.get_rect()

        if 'centered_x' in kwargs and kwargs['centered_x']:
            self.rect.x = self.screen.get_width() // 2 - self.rect.width // 2
        else:
            self.rect.x = x

        if 'centered_y' in kwargs and kwargs['cenntered_y']:
            self.rect.y = self.screen.get_height() // 2 - self.rect.height // 2
        else:
            self.rect.y = y

    def move(self):
        # screen.blit(self.surface, (self.x, self.y))
        self.screen.blit(self.img, self.rect)

    def check_click(self, position):
        x_match = position[0] > self.rect.x and position[0] < self.rect.x + self.rect.width
        y_match = position[1] > self.rect.y and position[1] < self.rect.y + self.rect.height

        if x_match and y_match:
            return True
        else:
            return False