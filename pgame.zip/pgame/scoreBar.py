import pygame
from base import *

class ScoreBar(Base):

    def __init__(self, screen):
        super().__init__(screen)

    def move(self):
        pass