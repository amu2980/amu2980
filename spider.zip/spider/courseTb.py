import requests
import bs4
from PIL import Image # 用于验证码图像的获取

class CourseTb:

    # 图片验证码url
    pic_url = 'http://210.40.2.253:8888/CheckCode.aspx'
    # 登录页面url
    base_url = 'http://210.40.2.253:8888/default2.aspx'
    # 系统首页url
    main_url = 'http://210.40.2.253:8888/xs_main.aspx?xh=1815000174'

    # 伪装头部信息
    headers = {'Referer': 'http://210.40.2.253:8888/xs_main.aspx?xh=1815000174',
               'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36 Edg/89.0.774.63'}
    # 构造session
    ss = requests.session()

    # 构造post data
    data = {}

    # 下载验证码图片，构造登录需要的参数字典
    @staticmethod
    def get_post_data():
        # 获取到登录界面的html
        html = requests.get(url=CourseTb.base_url, headers=CourseTb.headers)

        soup = bs4.BeautifulSoup(html.text, 'html.parser')

        # 找到form的验证参数
        __VIEWSTATE = soup.find('input', attrs={'name': '__VIEWSTATE'})['value']

        # 下载验证码图片
        pic = CourseTb.ss.get(CourseTb.pic_url,
                     headers=CourseTb.headers).content

        # 覆盖写入图片信息
        with open('./ver_pic.png', 'wb') as f:
            f.write(pic)

        # 打开验证码图片
        # image = Image.open('./ver_pic.png')
        # image.show()

        # 构造教务系统需要的post参数表
        CourseTb.data = {'txtUserName': '',
                'Textbox1': '',
                'TextBox2': '',
                'txtSecretCode': "",
                '__VIEWSTATE': __VIEWSTATE,
                'RadioButtonList1': '\xd1\xa7\xc9\xfa',
                'Button1': '',
                'lbLanguage': '',
                'hidPdrs': '',
                'hidsc': '', }

    @staticmethod
    def construct_data(account, password, verrification):
        # 补全登录的post参数
        CourseTb.data['txtSecretCode'] = verrification
        # data['txtUserName'] = input("学号：")
        CourseTb.data['txtUserName'] = account
        # data['TextBox2'] = input("密码：")
        CourseTb.data['TextBox2'] = password

        CourseTb.login()

    # 登录教务系统
    @staticmethod
    def login():
        # 通过requests库构造一个浏览器session，这能帮我们自动、持久的管理cookies
        CourseTb.ss.post(CourseTb.base_url, data= CourseTb.data, headers= CourseTb.headers)

    @staticmethod
    def get_courseTb():

        # data = CourseTb.__get_post_data(CourseTb.base_url)

        # CourseTb.__login(CourseTb.base_url, data)

        info = CourseTb.ss.get(url = CourseTb.main_url, headers = CourseTb.headers)

        info_soup = bs4.BeautifulSoup(info.text, 'html.parser')

        student = info_soup.find('span', attrs={'id': 'xhxm'})

        student = student.text[:-2]

        test = CourseTb.ss.get(
            url=f'http://210.40.2.253:8888/xskbcx.aspx?xh={CourseTb.data["txtUserName"]}&xm={student}&gnmkdm=N121603'
            , headers=CourseTb.headers)

        soup = bs4.BeautifulSoup(test.text, 'html.parser')

        course_tb = soup.find('table', attrs={'id': 'Table1'})

        tr = course_tb.find_all("tr")

        count = 0
        result = []
        element = []

        for each in tr:
            element.clear()
            count += 1
            if count % 2 == 0:
                continue
            td = each.find_all('td')
            for each2 in td:
                if each2.text not in ['早晨','上午','下午','晚上']:
                    element.append(each2.text if each2.text != "\xa0" else "null")
            result.append(element[:])

        newResult = []
        newResultItem = []

        for idx in range(1, len(result[0])):
            # print(result[0][idx])
            newResultItem.clear()
            newResultItem.append(result[0][idx])
            count = 1
            for idx2 in range(1, len(result)):
                # print(f"第{count},{count+1}节  {result[idx2][idx]}")
                newResultItem.append(result[idx2][idx])
                count += 2
            newResult.append(newResultItem.copy())

        return newResult

if __name__ == '__main__':

    try:

        CourseTb.get_post_data()

        CourseTb.login()

        result = CourseTb.get_courseTb()

        # for idx in range(1, len(result[0])):
        #     print(result[0][idx])
        #     count = 1
        #     for idx2 in range(1, len(result)):
        #         print(f"第{count},{count+1}节  {result[idx2][idx]}")
        #         count += 2
        #     print("-"*52)

        # newResult = []
        # newResultItem = []
        #
        # for idx in range(1, len(result[0])):
        #     # print(result[0][idx])
        #     newResultItem.clear()
        #     newResultItem.append(result[0][idx])
        #     count = 1
        #     for idx2 in range(1, len(result)):
        #         # print(f"第{count},{count+1}节  {result[idx2][idx]}")
        #         newResultItem.append(f"第{count},{count+1}节  {result[idx2][idx]}")
        #         count += 2
        #     newResult.append(newResultItem.copy())
        #     print("-"*52)

        print(result)

    except AttributeError as e:

        print("验证码或账户密码输入错误！")

    except requests.exceptions.ConnectionError as e:

        print("请检查网络连接！")