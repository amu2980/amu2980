import tkinter as tk
from PIL import ImageTk,Image
import tkinter.font as tf
import requests
import tkinter.ttk as ttk
import tkinter.scrolledtext as stxt
import tkinter.messagebox as msg
from courseTb import CourseTb as Ctb

# 主页面
class Home:

    def mainloop(self):
        self.master.mainloop()

    def __init__(self, master):
        self.master = master
        self.width = 1610
        self.height = 950
        self.table = []
        self.entry_val1 = tk.StringVar()
        self.entry_val2 = tk.StringVar()
        self.entry_val3 = tk.StringVar()
        self.setting()
        self.set_bg()
        self.set_button()
        self.set_entry()
        self.set_label()
        self.set_text()

    # 主页面配置
    def setting(self):
        self.master.title("课表")
        self.master.iconbitmap("./img/title.ico")
        self.master.resizable(False, False)
        sw = self.master.winfo_screenwidth()  # 获取屏幕宽度
        sh = self.master.winfo_screenheight()  # 获取屏幕高度
        # 指定窗口显示坐标
        x = (sw - self.width) / 2
        y = (sh - self.height) / 2
        self.master.geometry("%dx%d+%d+%d" % (self.width, self.height, x, y))

    def set_button(self):
        font = tf.Font(family="HeiTi", size=15, weight=tf.BOLD)
        search_btn = tk.Button(self.master,
                               text="查询",
                               font=font,
                               # image=searchImg,
                               bg="#419BC5")
        search_btn.bind('<Button-1>', self.to_submit)
        # search_btn.grid(row=5,column=11,pady = 50)
        search_btn.grid(row=3, column=3, padx=10)
        reset_btn = tk.Button(self.master,
                              text="重置",
                              font=font,
                              # image=resetImg,
                              # relief=tk.FLAT,
                              bg="#419BC5")
        reset_btn.bind('<Button-1>', self.to_reset)
        reset_btn.grid(row=3, column=5)

    def to_submit(self, event):
        account = self.entry_val1.get()
        password = self.entry_val2.get()
        verificationCode = self.entry_val3.get()

        if account != "" and password != "" and verificationCode != "":
            try:
                Ctb.construct_data(account, password, verificationCode)
                # 提交信息查询
                result = Ctb.get_courseTb()
                # 反馈显示结果
                for col_idx in range(len(result)):
                    for row_idx in range(len(result[0])-1):
                        # print(result[col_idx][row_idx+1]) # debug
                        self.table[row_idx+1][col_idx+1].config(state=tk.NORMAL)
                        self.table[row_idx+1][col_idx+1].delete(1.0, tk.END)
                        self.table[row_idx+1][col_idx+1].insert(1.0, result[col_idx][row_idx+1])
                        self.table[row_idx+1][col_idx+1].config(state=tk.DISABLED)
            except AttributeError as e:

                msg.showerror('参数错误','输入的信息有误！')

            except requests.exceptions.ConnectionError as e:

                msg.showerror('网络错误','请检查网络连接！')

    def to_reset(self, event):
        self.entry_val1.set("")
        self.entry_val2.set("")
        self.entry_val3.set("")

    def set_entry(self):
        #  学号账户输入框
        font1 = tf.Font(family="KaiTi", size=15, weight=tf.BOLD)
        label1 = tk.Label(self.master, text="学  号：", font=font1)
        label1.grid(row=2, column=1, columnspan=1, pady=30, padx = 40)
        entry1 = tk.Entry(self.master,
                               width=21,
                               relief=tk.SUNKEN,
                               font=font1,
                               justify = tk.CENTER,
                               textvariable = self.entry_val1)
        entry1.grid(row=2, column=2, columnspan=1, padx=10)
        #  密码输入框
        label2 = tk.Label(self.master, text="密  码：", font=font1)
        label2.grid(row=2, column=3, columnspan=1, pady=10, padx = 40)
        entry2 = tk.Entry(self.master,
                               width=21,
                               relief=tk.SUNKEN,
                               font=font1,
                               justify = tk.CENTER,
                               textvariable = self.entry_val2,
                               show = '*')
        entry2.grid(row=2, column=4, columnspan=1, padx=10)
        #  验证码输入框
        label3 = tk.Label(self.master, text="验证码：", font=font1)
        label3.grid(row=2, column=5, columnspan=1, pady=10, padx = 40)
        entry3 = tk.Entry(self.master,
                               width=21,
                               relief=tk.SUNKEN,
                               font=font1,
                               justify = tk.CENTER,
                               textvariable = self.entry_val3)
        entry3.grid(row=2, column=6, columnspan=1, padx=10)

    def set_label(self):
        verification_img = tk.Label(self.master, image=verImg)
        verification_img.grid(row=2, column=10, columnspan=1, padx=30)

    def set_text(self):
        font = tf.Font(family="KaiTi", size=13, weight=tf.BOLD)
        # 课表框
        self.frame = tk.Frame(self.master)
        row = []
        structure = [
            ["","Mon","Tue","Wed","Thu","Fri","Sat","Son"],
            ["\n\n\n第一节","","","","","","",""],
            ["\n\n\n第二节","","","","","","",""],
            ["\n\n\n第三节","","","","","","",""],
            ["\n\n\n第四节","","","","","","",""],
            ["\n\n\n第五节","","","","","","",""],
            ["\n\n\n第六节","","","","","","",""]
        ]
        # 表头行
        for j in range(8):
            if j in [0,6,7]:
                text = tk.Text(self.frame, width=10, height=1,
                           font=font)
            else :
                text = tk.Text(self.frame, width=24, height=1,
                               font=font)
            text.insert('end', structure[0][j])
            text.config(state=tk.DISABLED)
            text.grid(row=0, column=j, pady=0, padx=0)
            row.append(text)
        self.table.append(row.copy())
        # 表体
        for i in range(1,7):
            row.clear()
            for j in range(8):
                if j in [0,6,7]:
                    text = tk.Text(self.frame, width=10, height=7,
                                   font = font)
                else :
                    text = tk.Text(self.frame, width=24, height=7,
                                   font=font)
                text.insert('end', structure[i][j])
                text.config(state=tk.DISABLED)
                text.grid(row=i, column=j, pady = 0, padx = 0)
                row.append(text)
            self.table.append(row.copy())
        self.frame.grid(row = 4, column = 1, columnspan = 10, pady = 20, padx = 38)

    def set_bg(self):
        bg = tk.Label(self.master, image=bgImg)
        bg.place(x=0, y=0, relwidth=1, relheight=1)

root = tk.Tk()
data = Ctb.get_post_data()

# 全局加载图片
bg = Image.open("./img/bg4.png")
bg = bg.resize((1610, 950), Image.ANTIALIAS)
bgImg = ImageTk.PhotoImage(bg)
ver = Image.open("./ver_pic.png")
ver = ver.resize((144, 54), Image.ANTIALIAS)
verImg = ImageTk.PhotoImage(ver)


app = Home(root)

app.mainloop()